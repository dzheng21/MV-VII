//
//  SchedManagerViewController.swift
//  Bells
//
//  Created by Carolyn DUan on 7/11/16.
//  Copyright © 2016 Carolyn Duan. All rights reserved.
//

import UIKit

class SchedManagerViewController: UIViewController {

	override func viewDidLoad() {
		super.viewDidLoad()
		self.navigationController?.navigationBar.setValue(true, forKey: "hidesShadow")
	}

}
